package br.com.loja.teste;

import br.com.loja.conexao.Conexao;

public class Teste {
    public static void main(String[] args) {
        try {
            Conexao.conectar();
            System.out.println("Conectado com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}