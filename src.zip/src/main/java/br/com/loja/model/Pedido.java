package br.com.loja.model;

public class Pedido {
    private int id;
    private int idCliente;
    private String status;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
}