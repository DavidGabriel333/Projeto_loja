package br.com.loja.model;

public class Produto {
    private int id;
    private String nome;
    private String marca;
    private double preco;
    private int estoque;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
}