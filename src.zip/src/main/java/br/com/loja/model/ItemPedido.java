package br.com.loja.model;

public class ItemPedido {
    private int id;
    private int idPedido;
    private int idProduto;
    private int quantidade;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
}