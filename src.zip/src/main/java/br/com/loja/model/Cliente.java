package br.com.loja.model;

public class Cliente {
    private int id;
    private String nome;
    private String email;
    private String senha;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
}