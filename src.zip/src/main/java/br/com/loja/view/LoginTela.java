package br.com.loja.view;

import br.com.loja.dao.LoginDAO;
import javax.swing.*;
import java.awt.*;

public class LoginTela extends JFrame {

    private JTextField campoEmail;
    private JPasswordField campoSenha;

    public LoginTela() {

        setTitle("Login - Loja de Suplementos");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel titulo = new JLabel("LOGIN DO SISTEMA");
        titulo.setFont(new Font("Arial", Font.BOLD, 16));

        JLabel lblEmail = new JLabel("Email:");
        JLabel lblSenha = new JLabel("Senha:");

        campoEmail = new JTextField(15);
        campoSenha = new JPasswordField(15);

        JButton btnLogin = new JButton("Entrar");

        // 🔹 Título
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        add(titulo, gbc);

        // 🔹 Email
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        add(lblEmail, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        add(campoEmail, gbc);

        // 🔹 Senha
        gbc.gridy = 2;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        add(lblSenha, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        add(campoSenha, gbc);

        // 🔹 Botão
        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(btnLogin, gbc);

        btnLogin.addActionListener(e -> fazerLogin());

        setVisible(true);
    }

    private void fazerLogin() {
        String email = campoEmail.getText();
        String senha = new String(campoSenha.getPassword());

        int tipo = LoginDAO.login(email, senha);

        if (tipo == 0) {
            JOptionPane.showMessageDialog(this, "Login inválido!");
        } else if (tipo == -1) {
            new MenuGerenteTela();
            dispose();
        } else {
            new MenuClienteTela(tipo);
            dispose();
        }
    }
}