package br.com.loja.view;

import br.com.loja.conexao.Conexao;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class TelaCadastroProduto extends JFrame {

    public TelaCadastroProduto() {

        setTitle("Cadastrar Produto");
        setSize(300, 300);
        setLocationRelativeTo(null);

        setLayout(new GridLayout(6,2,5,5));

        JTextField nome = new JTextField();
        JTextField marca = new JTextField();
        JTextField preco = new JTextField();
        JTextField estoque = new JTextField();

        JButton salvar = new JButton("Salvar");
        JButton voltar = new JButton("Voltar");

        add(new JLabel("Nome:"));
        add(nome);
        add(new JLabel("Marca:"));
        add(marca);
        add(new JLabel("Preço:"));
        add(preco);
        add(new JLabel("Estoque:"));
        add(estoque);
        add(salvar);
        add(voltar);

        salvar.addActionListener(e -> {
            try (Connection conn = Conexao.conectar()) {

                PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO produto(nome, marca, preco, estoque) VALUES (?,?,?,?)"
                );

                ps.setString(1, nome.getText());
                ps.setString(2, marca.getText());
                ps.setDouble(3, Double.parseDouble(preco.getText()));
                ps.setInt(4, Integer.parseInt(estoque.getText()));

                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Produto cadastrado!");
                dispose();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
            }
        });

        voltar.addActionListener(e -> dispose());

        setVisible(true);
    }
}