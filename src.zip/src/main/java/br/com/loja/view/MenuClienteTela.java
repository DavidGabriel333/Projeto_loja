package br.com.loja.view;

import javax.swing.*;
import java.awt.*;

public class MenuClienteTela extends JFrame {

    public MenuClienteTela(int idCliente) {

        setTitle("Área do Cliente");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // 🔹 Layout principal
        setLayout(new BorderLayout());

        // 🔹 Título
        JLabel titulo = new JLabel("MENU DO CLIENTE", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 16));
        titulo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 🔹 Painel de botões
        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(3, 1, 10, 10));
        painel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));

        JButton btnProdutos = new JButton("Ver Produtos");
        JButton btnCarrinho = new JButton("Carrinho");
        JButton btnSair = new JButton("Sair / Logout");

        painel.add(btnProdutos);
        painel.add(btnCarrinho);
        painel.add(btnSair);

        // 🔹 Ações
        btnProdutos.addActionListener(e -> new TelaProdutos(idCliente));

        btnCarrinho.addActionListener(e -> new CarrinhoTela(idCliente));

        btnSair.addActionListener(e -> {
            int opcao = JOptionPane.showConfirmDialog(
                    this,
                    "Deseja voltar para o login?",
                    "Logout",
                    JOptionPane.YES_NO_OPTION
            );

            if (opcao == JOptionPane.YES_OPTION) {
                new LoginTela(); // volta pro login
                dispose(); // fecha essa tela
            } else {
                System.exit(0); // fecha o sistema
            }
        });

        // 🔹 Adicionando na tela
        add(titulo, BorderLayout.NORTH);
        add(painel, BorderLayout.CENTER);

        setVisible(true);
    }
}