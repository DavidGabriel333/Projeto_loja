package br.com.loja.view;

import br.com.loja.dao.*;
import javax.swing.*;
import java.awt.*;

public class MenuGerenteTela extends JFrame {

    public MenuGerenteTela() {

        setTitle("Gerente");
        setSize(350, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        setLayout(new GridLayout(6,1,10,10));

        JButton cadastrar = new JButton("Cadastrar Produto");
        JButton listar = new JButton("Listar Produtos");
        JButton excluir = new JButton("Excluir Produto");
        JButton vendas = new JButton("Ver Vendas");
        JButton faturamento = new JButton("Faturamento");
        JButton sair = new JButton("Sair / Logout"); // 🔥 NOVO

        add(cadastrar);
        add(listar);
        add(excluir);
        add(vendas);
        add(faturamento);
        add(sair);

        cadastrar.addActionListener(e -> new TelaCadastroProduto());

listar.addActionListener(e -> new TelaGerenciarProdutos());

excluir.addActionListener(e -> new TelaGerenciarProdutos());

vendas.addActionListener(e -> new TelaVendas());

faturamento.addActionListener(e -> {
    try (var conn = br.com.loja.conexao.Conexao.conectar()) {
        var rs = conn.createStatement().executeQuery(
            "SELECT SUM(i.quantidade * p.preco) FROM item_pedido i " +
            "JOIN produto p ON i.id_produto = p.id_produto"
        );
        if (rs.next()) {
            JOptionPane.showMessageDialog(this, "Faturamento: R$ " + rs.getDouble(1));
        }
    } catch (Exception ex) {
        ex.printStackTrace();
    }
});
        // 🔥 LOGOUT GERENTE
        sair.addActionListener(e -> {
            int opcao = JOptionPane.showConfirmDialog(
                    this,
                    "Deseja voltar para o login?",
                    "Logout",
                    JOptionPane.YES_NO_OPTION
            );

            if (opcao == JOptionPane.YES_OPTION) {
                new LoginTela();
                dispose();
            } else {
                System.exit(0);
            }
        });

        setVisible(true);
    }
}