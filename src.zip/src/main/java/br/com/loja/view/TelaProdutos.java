package br.com.loja.view;

import br.com.loja.conexao.Conexao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class TelaProdutos extends JFrame {

    private JTable tabela;
    private DefaultTableModel modelo;
    private int idCliente;

    public TelaProdutos(int idCliente) {
        this.idCliente = idCliente;

        setTitle("Produtos");
        setSize(650, 400);
        setLocationRelativeTo(null);

        modelo = new DefaultTableModel(
                new Object[]{"ID", "Nome", "Marca", "Preço", "Estoque"}, 0
        );

        tabela = new JTable(modelo);
        carregarProdutos();

        JScrollPane scroll = new JScrollPane(tabela);

        JButton btnAdicionar = new JButton("Adicionar ao Carrinho");
        JButton btnAtualizar = new JButton("Atualizar");
        JButton btnVoltar = new JButton("Voltar");

        btnAdicionar.addActionListener(e -> adicionarCarrinho());
        btnAtualizar.addActionListener(e -> carregarProdutos());
        btnVoltar.addActionListener(e -> dispose());

        JPanel painel = new JPanel();
        painel.add(btnAdicionar);
        painel.add(btnAtualizar);
        painel.add(btnVoltar);

        add(scroll, BorderLayout.CENTER);
        add(painel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void carregarProdutos() {
        modelo.setRowCount(0);

        try (Connection conn = Conexao.conectar()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM produto");

            while (rs.next()) {
                modelo.addRow(new Object[]{
                        rs.getInt("id_produto"),
                        rs.getString("nome"),
                        rs.getString("marca"),
                        rs.getDouble("preco"),
                        rs.getInt("estoque")
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void adicionarCarrinho() {
        int linha = tabela.getSelectedRow();

        if (linha == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um produto!");
            return;
        }

        int idProduto = (int) modelo.getValueAt(linha, 0);
        int estoque = (int) modelo.getValueAt(linha, 4);

        String qtdStr = JOptionPane.showInputDialog("Quantidade:");
        int qtd = Integer.parseInt(qtdStr);

        if (qtd > estoque) {
            JOptionPane.showMessageDialog(this, "Estoque insuficiente!");
            return;
        }

        CarrinhoTela.adicionarItem(idProduto, qtd);
        JOptionPane.showMessageDialog(this, "Produto adicionado ao carrinho!");
    }
}