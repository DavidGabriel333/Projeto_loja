package br.com.loja.view;

import br.com.loja.conexao.Conexao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class TelaVendas extends JFrame {

    public TelaVendas() {

        setTitle("Vendas");
        setSize(600, 400);
        setLocationRelativeTo(null);

        DefaultTableModel modelo = new DefaultTableModel(
                new Object[]{"Pedido","Cliente","Status","Pagamento"},0
        );

        JTable tabela = new JTable(modelo);

        try (Connection conn = Conexao.conectar()) {

            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT p.id_pedido, c.nome, p.status, p.pagamento " +
                    "FROM pedido p JOIN cliente c ON p.id_cliente = c.id_cliente"
            );

            while (rs.next()) {
                modelo.addRow(new Object[]{
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        JButton voltar = new JButton("Voltar");
        voltar.addActionListener(e -> dispose());

        add(new JScrollPane(tabela), BorderLayout.CENTER);
        add(voltar, BorderLayout.SOUTH);

        setVisible(true);
    }
}