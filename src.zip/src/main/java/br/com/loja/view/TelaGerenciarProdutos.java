package br.com.loja.view;

import br.com.loja.conexao.Conexao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class TelaGerenciarProdutos extends JFrame {

    private JTable tabela;
    private DefaultTableModel modelo;

    public TelaGerenciarProdutos() {

        setTitle("Gerenciar Produtos");
        setSize(600, 400);
        setLocationRelativeTo(null);

        modelo = new DefaultTableModel(
                new Object[]{"ID","Nome","Marca","Preço","Estoque"},0
        );

        tabela = new JTable(modelo);

        carregar();

        JButton excluir = new JButton("Excluir Produto");
        JButton atualizar = new JButton("Atualizar");
        JButton voltar = new JButton("Voltar");

        excluir.addActionListener(e -> excluir());
        atualizar.addActionListener(e -> carregar());
        voltar.addActionListener(e -> dispose());

        JPanel painel = new JPanel();
        painel.add(excluir);
        painel.add(atualizar);
        painel.add(voltar);

        add(new JScrollPane(tabela), BorderLayout.CENTER);
        add(painel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void carregar() {
        modelo.setRowCount(0);

        try (Connection conn = Conexao.conectar()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM produto");

            while (rs.next()) {
                modelo.addRow(new Object[]{
                        rs.getInt("id_produto"),
                        rs.getString("nome"),
                        rs.getString("marca"),
                        rs.getDouble("preco"),
                        rs.getInt("estoque")
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void excluir() {
        int linha = tabela.getSelectedRow();

        if (linha == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um produto!");
            return;
        }

        int id = (int) modelo.getValueAt(linha, 0);

        try (Connection conn = Conexao.conectar()) {

            PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM produto WHERE id_produto = ?"
            );

            ps.setInt(1, id);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Produto excluído!");
            carregar();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}