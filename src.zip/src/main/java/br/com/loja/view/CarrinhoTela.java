package br.com.loja.view;

import br.com.loja.conexao.Conexao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class CarrinhoTela extends JFrame {

    private static ArrayList<int[]> itens = new ArrayList<>();
    private JTable tabela;
    private DefaultTableModel modelo;
    private JLabel totalLabel;

    public CarrinhoTela(int idCliente) {

        setTitle("Carrinho");
        setSize(600, 400);
        setLocationRelativeTo(null);

        modelo = new DefaultTableModel(
                new Object[]{"Produto", "Preço", "Qtd", "Subtotal"}, 0
        );

        tabela = new JTable(modelo);
        totalLabel = new JLabel("Total: R$ 0");

        JButton btnFinalizar = new JButton("Finalizar Pedido");
        JButton btnVoltar = new JButton("Voltar");

        btnFinalizar.addActionListener(e -> finalizarPedido(idCliente));
        btnVoltar.addActionListener(e -> dispose());

        JPanel painel = new JPanel();
        painel.add(btnFinalizar);
        painel.add(btnVoltar);

        add(new JScrollPane(tabela), BorderLayout.CENTER);
        add(totalLabel, BorderLayout.NORTH);
        add(painel, BorderLayout.SOUTH);

        atualizarTabela();

        setVisible(true);
    }

    public static void adicionarItem(int idProduto, int qtd) {
        itens.add(new int[]{idProduto, qtd});
    }

    private void atualizarTabela() {
        modelo.setRowCount(0);
        double total = 0;

        try (Connection conn = Conexao.conectar()) {

            for (int[] item : itens) {
                int idProduto = item[0];
                int qtd = item[1];

                PreparedStatement ps = conn.prepareStatement(
                        "SELECT nome, preco FROM produto WHERE id_produto = ?"
                );

                ps.setInt(1, idProduto);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    String nome = rs.getString("nome");
                    double preco = rs.getDouble("preco");

                    double subtotal = preco * qtd;
                    total += subtotal;

                    modelo.addRow(new Object[]{nome, preco, qtd, subtotal});
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        totalLabel.setText("Total: R$ " + total);
    }

    private void finalizarPedido(int idCliente) {

        try (Connection conn = Conexao.conectar()) {

            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO pedido(id_cliente,status,pagamento) VALUES (?,?,?)",
                    Statement.RETURN_GENERATED_KEYS
            );

            ps.setInt(1, idCliente);
            ps.setString(2, "FINALIZADO");
            ps.setString(3, "PIX");
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            rs.next();
            int idPedido = rs.getInt(1);

            for (int[] item : itens) {

                PreparedStatement insert = conn.prepareStatement(
                        "INSERT INTO item_pedido(id_pedido,id_produto,quantidade) VALUES (?,?,?)"
                );

                insert.setInt(1, idPedido);
                insert.setInt(2, item[0]);
                insert.setInt(3, item[1]);
                insert.executeUpdate();

                PreparedStatement update = conn.prepareStatement(
                        "UPDATE produto SET estoque = estoque - ? WHERE id_produto = ?"
                );

                update.setInt(1, item[1]);
                update.setInt(2, item[0]);
                update.executeUpdate();
            }

            itens.clear();

            JOptionPane.showMessageDialog(this, "Pedido realizado!");
            dispose();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}