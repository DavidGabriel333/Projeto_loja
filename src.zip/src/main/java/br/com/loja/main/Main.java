package br.com.loja.main;

import br.com.loja.view.LoginTela;

public class Main {
    public static void main(String[] args) {
        new LoginTela();
    }
}