package br.com.loja.dao;

import br.com.loja.conexao.Conexao;
import java.sql.*;

public class LoginDAO {

    public static int login(String email, String senha) {
        try (Connection conn = Conexao.conectar()) {
            String sql = "SELECT id_cliente, tipo FROM cliente WHERE email=? AND senha=?";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, email);
            ps.setString(2, senha);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                if (rs.getString("tipo").equals("GERENTE")) {
                    return -1;
                } else {
                    return rs.getInt("id_cliente");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}