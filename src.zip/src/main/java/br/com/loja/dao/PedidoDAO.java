package br.com.loja.dao;

import br.com.loja.conexao.Conexao;
import java.sql.*;
import java.util.Scanner;

public class PedidoDAO {

    // CLIENTE - criar pedido com total
   public static void criarPedido(int idCliente) {
    Scanner sc = new Scanner(System.in);

    try (Connection conn = Conexao.conectar()) {

        System.out.print("Forma de pagamento (PIX/CARTAO): ");
        String pagamento = sc.next();

        PreparedStatement ps = conn.prepareStatement(
            "INSERT INTO pedido(id_cliente,status,pagamento) VALUES (?,?,?)",
            Statement.RETURN_GENERATED_KEYS
        );

        ps.setInt(1, idCliente);
        ps.setString(2, "PENDENTE");
        ps.setString(3, pagamento);
        ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        int idPedido = rs.getInt(1);

        double total = 0;
        int op;

        do {
            System.out.println("\n1 - Adicionar Item");
            System.out.println("2 - Remover Item");
            System.out.println("0 - Finalizar");
            System.out.print("Opção: ");
            op = sc.nextInt();

            if (op == 1) {
                total += ItemPedidoDAO.adicionarItem(idPedido);
            }

            if (op == 2) {
                System.out.print("ID do produto para remover: ");
                int idProd = sc.nextInt();

                PreparedStatement del = conn.prepareStatement(
                    "DELETE FROM item_pedido WHERE id_pedido = ? AND id_produto = ?"
                );

                del.setInt(1, idPedido);
                del.setInt(2, idProd);
                del.executeUpdate();

                System.out.println("Item removido!");
            }

        } while (op != 0);

        System.out.println("\nTOTAL DO PEDIDO: R$ " + total);

    } catch (Exception e) {
        e.printStackTrace();
    }
}
    // CLIENTE - ver pedidos dele
    public static void listarPedidosCliente(int idCliente) {
        try (Connection conn = Conexao.conectar()) {

            String sql = """
                SELECT id_pedido, status, pagamento
                FROM pedido
                WHERE id_cliente = ?
            """;

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idCliente);

            ResultSet rs = ps.executeQuery();

            System.out.println("\n--- MEUS PEDIDOS ---");

            while (rs.next()) {
                System.out.println("Pedido: " + rs.getInt("id_pedido")
                        + " | Status: " + rs.getString("status")
                        + " | Pagamento: " + rs.getString("pagamento"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // GERENTE - ver todas as vendas
    public static void listarVendas() {
        try (Connection conn = Conexao.conectar()) {

            String sql = """
                SELECT p.id_pedido, c.nome, p.status, p.pagamento
                FROM pedido p
                JOIN cliente c ON p.id_cliente = c.id_cliente
            """;

            ResultSet rs = conn.createStatement().executeQuery(sql);

            System.out.println("\n--- VENDAS ---");

            while (rs.next()) {
                System.out.println("Pedido: " + rs.getInt("id_pedido")
                        + " | Cliente: " + rs.getString("nome")
                        + " | Status: " + rs.getString("status")
                        + " | Pagamento: " + rs.getString("pagamento"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // GERENTE - faturamento total 💰
    public static void totalVendas() {
        try (Connection conn = Conexao.conectar()) {

            String sql = """
                SELECT SUM(p.preco * i.quantidade) AS total
                FROM item_pedido i
                JOIN produto p ON i.id_produto = p.id_produto
            """;

            ResultSet rs = conn.createStatement().executeQuery(sql);

            if (rs.next()) {
                System.out.println("\n==============================");
                System.out.println("FATURAMENTO TOTAL: R$ " + rs.getDouble("total"));
                System.out.println("==============================");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}