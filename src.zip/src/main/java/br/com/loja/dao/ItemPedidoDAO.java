package br.com.loja.dao;

import br.com.loja.conexao.Conexao;
import java.sql.*;
import java.util.Scanner;

public class ItemPedidoDAO {

    public static double adicionarItem(int idPedido) {
    Scanner sc = new Scanner(System.in);

    System.out.print("ID do produto: ");
    int idProduto = sc.nextInt();

    System.out.print("Quantidade: ");
    int qtd = sc.nextInt();

    double subtotal = 0;

    try (Connection conn = Conexao.conectar()) {

        PreparedStatement ps = conn.prepareStatement(
            "SELECT nome, preco, estoque FROM produto WHERE id_produto = ?"
        );
        ps.setInt(1, idProduto);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            String nome = rs.getString("nome");
            double preco = rs.getDouble("preco");
            int estoque = rs.getInt("estoque");

            // 🔥 VALIDA ESTOQUE
            if (qtd > estoque) {
                System.out.println("Erro: estoque insuficiente! Disponível: " + estoque);
                return 0;
            }

            subtotal = preco * qtd;

            // 🔥 ATUALIZA ESTOQUE
            PreparedStatement update = conn.prepareStatement(
                "UPDATE produto SET estoque = estoque - ? WHERE id_produto = ?"
            );
            update.setInt(1, qtd);
            update.setInt(2, idProduto);
            update.executeUpdate();

            PreparedStatement insert = conn.prepareStatement(
                "INSERT INTO item_pedido(id_pedido,id_produto,quantidade) VALUES (?,?,?)"
            );

            insert.setInt(1, idPedido);
            insert.setInt(2, idProduto);
            insert.setInt(3, qtd);
            insert.executeUpdate();

            System.out.println("Produto: " + nome);
            System.out.println("Subtotal: R$ " + subtotal);

        } else {
            System.out.println("Produto não encontrado!");
            return 0;
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return subtotal;
}
}