package br.com.loja.dao;

import br.com.loja.conexao.Conexao;
import java.sql.*;
import java.util.Scanner;

public class ProdutoDAO {

    public static void cadastrar() {
    Scanner sc = new Scanner(System.in);

    System.out.print("Nome: ");
    String nome = sc.nextLine();

    System.out.print("Marca: ");
    String marca = sc.nextLine();

    System.out.print("Preço: ");
    double preco = sc.nextDouble();

    System.out.print("Estoque: ");
    int estoque = sc.nextInt();

    try (Connection conn = Conexao.conectar()) {

        // 🔥 VERIFICA SE JÁ EXISTE
        PreparedStatement check = conn.prepareStatement(
            "SELECT COUNT(*) FROM produto WHERE nome = ?"
        );
        check.setString(1, nome);

        ResultSet rs = check.executeQuery();
        rs.next();

        if (rs.getInt(1) > 0) {
            System.out.println("Erro: Já existe produto com esse nome!");
            return;
        }

        PreparedStatement ps = conn.prepareStatement(
            "INSERT INTO produto(nome, marca, preco, estoque) VALUES (?,?,?,?)"
        );

        ps.setString(1, nome);
        ps.setString(2, marca);
        ps.setDouble(3, preco);
        ps.setInt(4, estoque);
        ps.executeUpdate();

        System.out.println("Produto cadastrado!");

    } catch (Exception e) {
        e.printStackTrace();
    }
}

    public static void listar() {
    try (Connection conn = Conexao.conectar()) {

        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM produto");

        System.out.println("\n==============================");
        System.out.println("        LISTA DE PRODUTOS     ");
        System.out.println("==============================");

        while (rs.next()) {
            System.out.println(
                "ID: " + rs.getInt("id_produto") +
                " | Nome: " + rs.getString("nome") +
                " | Marca: " + rs.getString("marca") +
                " | Preço: R$ " + rs.getDouble("preco") +
                " | Estoque: " + rs.getInt("estoque")
            );
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
}
    

    public static void excluir() {
    Scanner sc = new Scanner(System.in);

    System.out.print("ID do produto para excluir: ");
    int id = sc.nextInt();

    try (Connection conn = Conexao.conectar()) {

        PreparedStatement ps = conn.prepareStatement(
            "DELETE FROM produto WHERE id_produto = ?"
        );

        ps.setInt(1, id);
        int linhas = ps.executeUpdate();

        if (linhas > 0) {
            System.out.println("Produto excluído com sucesso!");
        } else {
            System.out.println("Produto não encontrado.");
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
}
}
