Sistema Loja de Suplementos

 Descrição
Sistema desenvolvido em Java com interface gráfica para gerenciamento de uma loja de suplementos.

Permite cadastro de produtos, controle de estoque, carrinho de compras e registro de pedidos.

 Tecnologias Utilizadas
- Java (Swing)
- PostgreSQL
- JDBC

 Funcionalidades
- Login de cliente e gerente
- Cadastro de produtos
- Exclusão de produtos
- Carrinho de compras
- Finalização de pedidos
- Controle de estoque
- Faturamento

 Diagrama DER
Disponível na pasta /diagrama

 Instruções de Execução

1. Instalar PostgreSQL

2. Criar banco:
sql
CREATE DATABASE suplementos;